package org.example.mvc.controller;

import org.example.mvc.dao.UserDAO;
import org.example.mvc.entity.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController
{
	@Autowired
	UserDAO udao;
	
	@GetMapping("/loginPage")
	public String getLoginPage()
	{
		return "Login";
	}
	@PostMapping("/validateUser")
	public String authenticateUser(@RequestParam("uname") String username, @RequestParam("pword") String password, Model model)
	{
		String message = "Invalid Username / Password.....Try Again...!";
		Users user = new Users(username, password);
		if(udao.validateUser(user))
		{
			return "SearchFlights";
		}
		model.addAttribute("message", message);
		return "Display";
	}
}
