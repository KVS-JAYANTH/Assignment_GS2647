package org.example.mvc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.example.mvc.entity.Flight;
import org.springframework.stereotype.Repository;

@Repository
public class FlightsDAO 
{
	private static String url ="jdbc:mysql://localhost:3306/testing";
	public List<Flight> searchFlights(String source, String destination)
	{
		List<Flight> fl = new ArrayList<Flight>();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs =  null;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url,"root","rootuser1");
			pst = con.prepareStatement("select * from flights where source=? and destination=?");
			pst.setString(1, source);
			pst.setString(2, destination);
			rs = pst.executeQuery();
			while(rs.next())
			{
				fl.add(new Flight(rs.getString(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getInt(5)));
				System.out.println("flights:   " + rs.getString(1)+rs.getString(2)+rs.getString(3)+rs.getDouble(4)+rs.getInt(5));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(rs!=null) rs.close();
				if(pst!=null) pst.close();
				if(con!=null) con.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return fl;
	}
}

