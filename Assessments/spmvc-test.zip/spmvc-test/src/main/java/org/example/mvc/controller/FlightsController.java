package org.example.mvc.controller;

import java.util.List;

import org.example.mvc.dao.FlightsDAO;
import org.example.mvc.entity.Flight;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FlightsController
{
	@Autowired
	FlightsDAO fdao;
	
	@PostMapping("/searchFlights")
	public String searchFlight(@RequestParam("source") String source, @RequestParam("destination") String destination, Model model)
	{
		List<Flight> fList=fdao.searchFlights(source,destination);
		
		model.addAttribute("flights", fList);
		return "FlightBooking";
	}
}
